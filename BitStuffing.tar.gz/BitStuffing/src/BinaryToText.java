import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class BinaryToText {
	
	
	

	public String discardZeros(String stuffedBits) {

		String discardedText = "";

		int coun_one_s = 0;

		for (int i = 0; i < stuffedBits.length(); i++) {

			char c = stuffedBits.charAt(i);

			if (c == '1') {
				coun_one_s++;
				if (coun_one_s == 5) {

					String firstPart = stuffedBits.substring(0, i + 1);
					String secondPart = stuffedBits.substring(i + 2);
					// System.out.println(firstPart);
					discardedText += firstPart;
					// System.out.println(secondPart);
					stuffedBits = secondPart;
					i = 0;
					coun_one_s = 0;
				}
			} else {
				coun_one_s = 0;
			}
			// System.out.println(cInd);
		}
		discardedText += stuffedBits;
		System.out.println("Bit String After Discarded Zeros:");
		System.out.println(discardedText);

		return discardedText;

	}
	
	
	public String convertToText(String binary){
		
		
		String discardedText = discardZeros(binary);
		int i = 0; 
		String convertedText = "";
		
		//7 is the maximum digit size fr an ASCII char so the binary forms of charachters are fixed to  digit
		
		for (int j = 0; j < discardedText.length(); j=j+7) {
			
			String bin_char = discardedText.substring(j, j+7);
			int decimalValue = Integer.parseInt(bin_char, 2);
			String c = Character.toString ((char) decimalValue); 
			convertedText += c;
		}
		
		
		
		return convertedText;
	}

	public void writeToFile(String resultString) {

		try {
			
			File file = new File("bitStuffing.txt");
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(resultString);
			bw.close();

			System.out.println("Done");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
