import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class TextToBinary {
	
	public String ASCII;

	
	/*
	 * reads from file character by character and converts to binary
	 * returns whole binary string
	 */
	public String convertTextToBinary(String fileName) {

		String binary = "";
		String wholeTextBinary = "";
		try {
			

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName), Charset.forName("UTF-8")));
			int c;
			while ((c = reader.read()) != -1) {
				char character = (char) c;
				
				binary = Integer.toBinaryString(c);
				while(binary.length()<7){
					binary = "0" + binary;
				}
				wholeTextBinary += binary;
//				System.out.println(character + " " + c + " " + binary);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Original Bit String :");
		System.out.println(wholeTextBinary);
		return wholeTextBinary;
	}
	
	
	/*
	 * gets binary string as parameter and adds zero after d after every five consecutive ones
	 */

	public String aplyBitStuffing(String binary) {

		String stuffedBits = "";
		
		int coun_one_s = 0;

		for (int i = 0; i < binary.length(); i++) {

			char c = binary.charAt(i);

			if (c == '1') {
				coun_one_s++;
				//if the binary char is 1 counts next ones 
				if (coun_one_s == 5) {

					String firstPart = binary.substring(0, i + 1);
					String secondPart = binary.substring(i + 1);
					stuffedBits += firstPart + "0";
					binary = secondPart;
					i = 0;

					coun_one_s = 0;

				}
			} else {
				coun_one_s = 0;
			}

		}
		stuffedBits += binary;
		System.out.println("Stuffed Bit String:");
		System.out.println(stuffedBits);

		return stuffedBits;
	}

}
