
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String fileName = "text";
		
		
		TextToBinary textToBinary = new TextToBinary();		
		// text file is read and converted to binary string and applied bit stuffing  
		String binaryString = textToBinary.convertTextToBinary(fileName);
		String stuffedString = textToBinary.aplyBitStuffing(binaryString);
		
		//Stuffed text is given as parameter,stuffed zeros are discards and conerted back to the text 
		BinaryToText binaryToText = new BinaryToText();
		String convetedTxt = binaryToText.convertToText(stuffedString);

		System.out.println("Conveted Text:");
		System.out.println(convetedTxt);
		
		binaryToText.writeToFile(convetedTxt);
		
	}

}
